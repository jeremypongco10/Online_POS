-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: pos_system
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cash_movements`
--

DROP TABLE IF EXISTS `cash_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cash_session_id` bigint(20) unsigned NOT NULL,
  `type` enum('cash_in','cash_out') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_movements_user_id_foreign` (`user_id`),
  KEY `cash_session_id` (`cash_session_id`),
  CONSTRAINT `cash_movements_cash_session_id_foreign` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cash_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_movements`
--

LOCK TABLES `cash_movements` WRITE;
/*!40000 ALTER TABLE `cash_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_sessions`
--

DROP TABLE IF EXISTS `cash_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `opened_at` datetime NOT NULL,
  `closed_at` datetime DEFAULT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `closing_balance` decimal(15,2) DEFAULT NULL,
  `expected_balance` decimal(15,2) DEFAULT NULL,
  `difference` decimal(15,2) DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `register_id` (`register_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  CONSTRAINT `cash_sessions_register_id_foreign` FOREIGN KEY (`register_id`) REFERENCES `registers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cash_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_sessions`
--

LOCK TABLES `cash_sessions` WRITE;
/*!40000 ALTER TABLE `cash_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_name` (`company_id`,`name`),
  KEY `company_id` (`company_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `trade_name` varchar(150) NOT NULL,
  `legal_name` varchar(150) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `is_vat_registered` tinyint(1) unsigned DEFAULT 0,
  `vat_registration_number` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `timezone` varchar(64) NOT NULL DEFAULT 'UTC',
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`trade_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Default Company','Default Company',NULL,0,NULL,NULL,NULL,NULL,'USD','UTC',1,'2026-08-16 16:41:35','2026-08-16 16:41:35');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `customer_code` varchar(30) DEFAULT NULL,
  `first_name` varchar(75) NOT NULL,
  `last_name` varchar(75) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_company_code_unique` (`company_id`,`customer_code`),
  KEY `company_id` (`company_id`),
  KEY `phone` (`mobile`),
  KEY `email` (`email`),
  CONSTRAINT `customers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `quantity` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `reorder_level` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id_store_id` (`product_id`,`store_id`),
  KEY `store_id` (`store_id`),
  CONSTRAINT `inventory_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventory_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transactions`
--

DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `type` enum('purchase','sale','return','adjustment','transfer_in','transfer_out') NOT NULL,
  `quantity` decimal(15,4) NOT NULL,
  `balance_after` decimal(15,4) NOT NULL,
  `reference_type` varchar(60) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_transactions_user_id_foreign` (`user_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `product_id` (`product_id`),
  KEY `store_id` (`store_id`),
  KEY `reference_type_reference_id` (`reference_type`,`reference_id`),
  KEY `idx_invtx_store_type_created` (`store_id`,`type`,`created_at`),
  CONSTRAINT `inventory_transactions_inventory_id_foreign` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventory_transactions_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_transactions_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transactions`
--

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_sequences`
--

DROP TABLE IF EXISTS `invoice_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_sequences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `type` enum('sale','purchase_order','return') NOT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `last_number` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_store_id_type` (`company_id`,`store_id`,`type`),
  KEY `company_id` (`company_id`),
  KEY `store_id` (`store_id`),
  CONSTRAINT `invoice_sequences_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_sequences_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_sequences`
--

LOCK TABLES `invoice_sequences` WRITE;
/*!40000 ALTER TABLE `invoice_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_cards`
--

DROP TABLE IF EXISTS `loyalty_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `card_number` varchar(40) NOT NULL,
  `status` enum('active','inactive','blocked','lost') NOT NULL DEFAULT 'inactive',
  `points` bigint(20) NOT NULL DEFAULT 0,
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `issued_at` datetime DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_number` (`card_number`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `loyalty_cards_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_cards`
--

LOCK TABLES `loyalty_cards` WRITE;
/*!40000 ALTER TABLE `loyalty_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026-08-15-000001','App\\Database\\Migrations\\CreateCompanies','default','App',1786898482,1),(2,'2026-08-15-000002','App\\Database\\Migrations\\CreateStores','default','App',1786898482,1),(3,'2026-08-15-000003','App\\Database\\Migrations\\CreateRoles','default','App',1786898482,1),(4,'2026-08-15-000004','App\\Database\\Migrations\\CreatePermissions','default','App',1786898482,1),(5,'2026-08-15-000005','App\\Database\\Migrations\\CreateRolePermissions','default','App',1786898482,1),(6,'2026-08-15-000006','App\\Database\\Migrations\\CreateUsers','default','App',1786898482,1),(7,'2026-08-15-000007','App\\Database\\Migrations\\CreateUserStores','default','App',1786898482,1),(8,'2026-08-15-000008','App\\Database\\Migrations\\CreateRegisters','default','App',1786898482,1),(9,'2026-08-15-000009','App\\Database\\Migrations\\CreateCashSessions','default','App',1786898482,1),(10,'2026-08-15-000010','App\\Database\\Migrations\\CreateUnits','default','App',1786898482,1),(11,'2026-08-15-000011','App\\Database\\Migrations\\CreateCategories','default','App',1786898482,1),(12,'2026-08-15-000012','App\\Database\\Migrations\\CreateTaxRates','default','App',1786898482,1),(13,'2026-08-15-000013','App\\Database\\Migrations\\CreateProducts','default','App',1786898482,1),(14,'2026-08-15-000014','App\\Database\\Migrations\\CreateProductPrices','default','App',1786898482,1),(15,'2026-08-15-000015','App\\Database\\Migrations\\CreateInventory','default','App',1786898482,1),(16,'2026-08-15-000016','App\\Database\\Migrations\\CreateInventoryTransactions','default','App',1786898482,1),(17,'2026-08-15-000017','App\\Database\\Migrations\\CreateCustomers','default','App',1786898482,1),(18,'2026-08-15-000018','App\\Database\\Migrations\\CreateLoyaltyCards','default','App',1786898482,1),(19,'2026-08-15-000019','App\\Database\\Migrations\\CreateSuppliers','default','App',1786898482,1),(20,'2026-08-15-000020','App\\Database\\Migrations\\CreatePurchaseOrders','default','App',1786898482,1),(21,'2026-08-15-000021','App\\Database\\Migrations\\CreatePurchaseOrderItems','default','App',1786898482,1),(22,'2026-08-15-000022','App\\Database\\Migrations\\CreateSales','default','App',1786898482,1),(23,'2026-08-15-000023','App\\Database\\Migrations\\CreateSaleItems','default','App',1786898482,1),(24,'2026-08-15-000024','App\\Database\\Migrations\\CreatePayments','default','App',1786898482,1),(25,'2026-08-15-000025','App\\Database\\Migrations\\CreateReturns','default','App',1786898482,1),(26,'2026-08-15-000026','App\\Database\\Migrations\\CreateReturnItems','default','App',1786898482,1),(27,'2026-08-15-000027','App\\Database\\Migrations\\CreateInvoiceSequences','default','App',1786898482,1),(28,'2026-08-15-000028','App\\Database\\Migrations\\AddLoginSecurityToUsers','default','App',1786898482,1),(29,'2026-08-15-000029','App\\Database\\Migrations\\CreateRevokedTokens','default','App',1786898482,1),(30,'2026-08-15-000030','App\\Database\\Migrations\\UpdateCompanyFields','default','App',1786898482,1),(31,'2026-08-15-000031','App\\Database\\Migrations\\EnforceCompanyTradeNameNotNull','default','App',1786898482,1),(32,'2026-08-16-000032','App\\Database\\Migrations\\AddPasswordChangedAtToUsers','default','App',1786898482,1),(33,'2026-08-16-000033','App\\Database\\Migrations\\AddPrecisionToUnits','default','App',1786898482,1),(34,'2026-08-16-000034','App\\Database\\Migrations\\AddSellingPriceAndMinStockToProducts','default','App',1786898482,1),(35,'2026-08-16-000035','App\\Database\\Migrations\\AddTaxRateIdToLineItems','default','App',1786898483,1),(36,'2026-08-16-000036','App\\Database\\Migrations\\SplitTransferTransactionType','default','App',1786898483,1),(37,'2026-08-16-000037','App\\Database\\Migrations\\UpdateCustomerFields','default','App',1786898483,1),(38,'2026-08-16-000038','App\\Database\\Migrations\\UpdateLoyaltyCardFields','default','App',1786898483,1),(39,'2026-08-16-000039','App\\Database\\Migrations\\EnforceCustomerNameFieldsNotNull','default','App',1786898483,1),(40,'2026-08-16-000040','App\\Database\\Migrations\\AddApprovalToPurchaseOrders','default','App',1786898483,1),(41,'2026-08-16-000041','App\\Database\\Migrations\\AddBaggerIdToSales','default','App',1786898483,1),(42,'2026-08-16-000042','App\\Database\\Migrations\\UpdatePaymentMethods','default','App',1786898483,1),(43,'2026-08-16-000043','App\\Database\\Migrations\\CreateCashMovements','default','App',1786898483,1),(44,'2026-08-16-000044','App\\Database\\Migrations\\AddInvoiceSnapshotFields','default','App',1786898483,1),(45,'2026-08-16-000045','App\\Database\\Migrations\\AddApprovalToReturns','default','App',1786898483,1),(46,'2026-08-16-000046','App\\Database\\Migrations\\AddPerformanceIndexes','default','App',1786898483,1),(47,'2026-08-16-000047','App\\Database\\Migrations\\MakeSalesReportIndexCovering','default','App',1786898483,1),(48,'2026-08-16-000048','App\\Database\\Migrations\\MakeSaleItemsJoinIndexCovering','default','App',1786898483,1),(49,'2026-08-18-000049','App\\Database\\Migrations\\DropUnusedProductPrices','default','App',1787055928,2),(50,'2026-08-18-000050','App\\Database\\Migrations\\CreateStoreProductPrices','default','App',1787055928,2),(51,'2026-08-18-000051','App\\Database\\Migrations\\DropProductPriceColumns','default','App',1787055928,2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `method` enum('cash','card','gcash','maya','bank_transfer','other') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `paid_at` datetime NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `method` (`method`),
  CONSTRAINT `payments_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'View Products','products.view','Can view product records','2026-08-16 16:41:35','2026-08-16 16:41:35'),(2,'Create Products','products.create','Can create new products','2026-08-16 16:41:35','2026-08-16 16:41:35'),(3,'Update Products','products.update','Can edit existing products','2026-08-16 16:41:35','2026-08-16 16:41:35'),(4,'Delete Products','products.delete','Can delete products','2026-08-16 16:41:35','2026-08-16 16:41:35'),(5,'View Inventory','inventory.view','Can view stock levels','2026-08-16 16:41:35','2026-08-16 16:41:35'),(6,'Adjust Inventory','inventory.adjust','Can make manual stock adjustments','2026-08-16 16:41:35','2026-08-16 16:41:35'),(7,'Transfer Inventory','inventory.transfer','Can transfer stock between stores','2026-08-16 16:41:35','2026-08-16 16:41:35'),(8,'Create Sales','sales.create','Can ring up new sales','2026-08-16 16:41:35','2026-08-16 16:41:35'),(9,'View Sales','sales.view','Can view sales history','2026-08-16 16:41:35','2026-08-16 16:41:35'),(10,'Void Sales','sales.void','Can void a sale','2026-08-16 16:41:35','2026-08-16 16:41:35'),(11,'Refund Sales','sales.refund','Can process a refund','2026-08-16 16:41:35','2026-08-16 16:41:35'),(12,'View Customers','customers.view','Can view customer records','2026-08-16 16:41:35','2026-08-16 16:41:35'),(13,'Create Customers','customers.create','Can create new customers','2026-08-16 16:41:35','2026-08-16 16:41:35'),(14,'Update Customers','customers.update','Can edit existing customers','2026-08-16 16:41:35','2026-08-16 16:41:35'),(15,'View Loyalty','loyalty.view','Can view loyalty card balances and points','2026-08-16 16:41:35','2026-08-16 16:41:35'),(16,'Manage Loyalty','loyalty.manage','Can issue cards and adjust points/balance','2026-08-16 16:41:35','2026-08-16 16:41:35'),(17,'View Reports','reports.view','Can view sales and inventory reports','2026-08-16 16:41:35','2026-08-16 16:41:35'),(18,'View Users','users.view','Can view user accounts','2026-08-16 16:41:35','2026-08-16 16:41:35'),(19,'Create Users','users.create','Can create new user accounts','2026-08-16 16:41:35','2026-08-16 16:41:35'),(20,'Update Users','users.update','Can edit existing user accounts','2026-08-16 16:41:35','2026-08-16 16:41:35'),(21,'View Stores','stores.view','Can view store records','2026-08-16 16:41:35','2026-08-16 16:41:35'),(22,'Manage Stores','stores.manage','Can create and edit stores','2026-08-16 16:41:35','2026-08-16 16:41:35'),(23,'View Companies','companies.view','Can view company records','2026-08-16 16:41:35','2026-08-16 16:41:35'),(24,'Manage Companies','companies.manage','Can create and edit companies','2026-08-16 16:41:35','2026-08-16 16:41:35'),(25,'View Roles','roles.view','Can view roles and their permissions','2026-08-16 16:41:35','2026-08-16 16:41:35'),(26,'Manage Roles','roles.manage','Can create/edit roles and assign permissions','2026-08-16 16:41:35','2026-08-16 16:41:35'),(27,'View Categories','categories.view','Can view product categories','2026-08-16 16:41:35','2026-08-16 16:41:35'),(28,'Manage Categories','categories.manage','Can create and edit categories','2026-08-16 16:41:35','2026-08-16 16:41:35'),(29,'View Units','units.view','Can view units of measure','2026-08-16 16:41:35','2026-08-16 16:41:35'),(30,'Manage Units','units.manage','Can create and edit units of measure','2026-08-16 16:41:35','2026-08-16 16:41:35'),(31,'View Taxes','taxes.view','Can view tax rate configuration','2026-08-16 16:41:35','2026-08-16 16:41:35'),(32,'Manage Taxes','taxes.manage','Can create and edit tax rates','2026-08-16 16:41:35','2026-08-16 16:41:35'),(33,'View Suppliers','suppliers.view','Can view supplier records','2026-08-16 16:41:35','2026-08-16 16:41:35'),(34,'Manage Suppliers','suppliers.manage','Can create and edit suppliers','2026-08-16 16:41:35','2026-08-16 16:41:35'),(35,'View Purchases','purchases.view','Can view purchase orders','2026-08-16 16:41:35','2026-08-16 16:41:35'),(36,'Create Purchases','purchases.create','Can create purchase orders','2026-08-16 16:41:35','2026-08-16 16:41:35'),(37,'Manage Purchases','purchases.manage','Can edit and receive purchase orders','2026-08-16 16:41:35','2026-08-16 16:41:35'),(38,'View Registers','registers.view','Can view POS registers','2026-08-16 16:41:35','2026-08-16 16:41:35'),(39,'Manage Registers','registers.manage','Can create and edit registers','2026-08-16 16:41:35','2026-08-16 16:41:35'),(40,'View Cash Sessions','cash-sessions.view','Can view cash drawer sessions','2026-08-16 16:41:35','2026-08-16 16:41:35'),(41,'Manage Cash Sessions','cash-sessions.manage','Can open and close cash drawer sessions','2026-08-16 16:41:35','2026-08-16 16:41:35'),(42,'View Payments','payments.view','Can view sale payments','2026-08-16 16:41:35','2026-08-16 16:41:35'),(43,'View Returns','returns.view','Can view sales returns','2026-08-16 16:41:35','2026-08-16 16:41:35'),(44,'Create Returns','returns.create','Can request a sales return','2026-08-16 16:41:35','2026-08-16 16:41:35'),(45,'Approve Returns','returns.approve','Can approve a pending return, issuing the refund and restocking inventory','2026-08-16 16:41:35','2026-08-16 16:41:35');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `tax_rate_id` bigint(20) unsigned DEFAULT NULL,
  `sku` varchar(60) NOT NULL,
  `barcode` varchar(60) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `minimum_stock` decimal(15,4) DEFAULT 0.0000,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `track_inventory` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_sku` (`company_id`,`sku`),
  UNIQUE KEY `company_id_barcode` (`company_id`,`barcode`),
  KEY `company_id` (`company_id`),
  KEY `category_id` (`category_id`),
  KEY `unit_id` (`unit_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `name` (`name`),
  KEY `idx_products_company_active` (`company_id`,`is_active`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `products_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_tax_rate_id_foreign` FOREIGN KEY (`tax_rate_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` decimal(15,4) NOT NULL,
  `unit_cost` decimal(15,2) NOT NULL,
  `tax_rate` decimal(7,4) NOT NULL DEFAULT 0.0000,
  `line_total` decimal(15,2) NOT NULL,
  `received_quantity` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_id` (`purchase_order_id`),
  KEY `product_id` (`product_id`),
  KEY `poi_tax_rate_id_fk` (`tax_rate_id`),
  CONSTRAINT `poi_tax_rate_id_fk` FOREIGN KEY (`tax_rate_id`) REFERENCES `tax_rates` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `purchase_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_order_items_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `po_number` varchar(40) NOT NULL,
  `status` enum('draft','approved','received','cancelled') NOT NULL DEFAULT 'draft',
  `order_date` date DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `expected_date` date DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_po_number` (`company_id`,`po_number`),
  KEY `purchase_orders_user_id_foreign` (`user_id`),
  KEY `company_id` (`company_id`),
  KEY `store_id` (`store_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `status` (`status`),
  KEY `po_approved_by_fk` (`approved_by`),
  CONSTRAINT `po_approved_by_fk` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `purchase_orders_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchase_orders_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_orders_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registers`
--

DROP TABLE IF EXISTS `registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(30) NOT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `store_id_code` (`store_id`,`code`),
  KEY `store_id` (`store_id`),
  CONSTRAINT `registers_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registers`
--

LOCK TABLES `registers` WRITE;
/*!40000 ALTER TABLE `registers` DISABLE KEYS */;
INSERT INTO `registers` VALUES (1,1,'Register 1','R1',1,'2026-08-16 16:43:31','2026-08-16 16:43:31'),(2,3,'Register 2','002',1,'2026-08-20 09:20:01','2026-08-20 09:20:01');
/*!40000 ALTER TABLE `registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_items`
--

DROP TABLE IF EXISTS `return_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` bigint(20) unsigned NOT NULL,
  `sale_item_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` decimal(15,4) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `refund_amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `sale_item_id` (`sale_item_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `return_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_return_id_foreign` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `return_items_sale_item_id_foreign` FOREIGN KEY (`sale_item_id`) REFERENCES `sale_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_items`
--

LOCK TABLES `return_items` WRITE;
/*!40000 ALTER TABLE `return_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `return_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `return_number` varchar(40) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `total_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `return_date` datetime NOT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `sale_id` (`sale_id`),
  KEY `store_id` (`store_id`),
  KEY `user_id` (`user_id`),
  KEY `customer_id` (`customer_id`),
  KEY `returns_approved_by_fk` (`approved_by`),
  CONSTRAINT `returns_approved_by_fk` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `returns_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `returns_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revoked_tokens`
--

DROP TABLE IF EXISTS `revoked_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revoked_tokens` (
  `jti` varchar(36) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime NOT NULL,
  PRIMARY KEY (`jti`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `revoked_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revoked_tokens`
--

LOCK TABLES `revoked_tokens` WRITE;
/*!40000 ALTER TABLE `revoked_tokens` DISABLE KEYS */;
INSERT INTO `revoked_tokens` VALUES ('0260be55748291fa65b4f251b8f1a5c1',4,'2026-08-20 11:08:54','2026-08-20 10:09:31'),('11ba4e31bd19fe6027edbdaafda97ce4',4,'2026-09-02 19:11:31','2026-08-19 20:13:55'),('13869b139a0f5d51f6b5a5edc2ec600c',4,'2026-09-01 21:19:07','2026-08-19 19:57:19'),('13a837e484035aa4f7c6329fd270ae3e',5,'2026-08-20 11:51:14','2026-08-20 11:02:53'),('21dbc7db2a020af9813576ccfbfee6df',4,'2026-09-02 21:20:35','2026-08-19 21:25:47'),('31d87a6e28d5680f2c261164f004643d',4,'2026-09-03 12:03:46','2026-08-20 13:19:57'),('3372c6925afb89d52a9b1048bb6b9bcf',4,'2026-09-02 20:20:10','2026-08-19 21:20:35'),('34676c108c4b663bdfd55d84dbbd9bec',4,'2026-09-02 20:18:40','2026-08-19 20:19:11'),('4523ea7f1c62657c707f418305726db4',5,'2026-08-19 20:58:19','2026-08-19 19:58:34'),('47f1e592ad86f6ef34b4db4482b3f614',5,'2026-08-20 11:09:43','2026-08-20 10:15:28'),('4b9b40064915e1f7da24244e17c4d61f',5,'2026-08-20 11:28:23','2026-08-20 10:30:42'),('694e6691b593245ede96e8d99760c256',5,'2026-08-20 11:34:55','2026-08-20 10:38:03'),('7146f2b8d106324ef52e67fd051d706a',5,'2026-08-20 12:03:02','2026-08-20 12:02:45'),('74d4d05f4ad5b13c2dd8f7882d32a219',5,'2026-09-02 22:00:31','2026-08-20 08:24:48'),('7a3e06c0b41e1d8f63794a747fee6633',5,'2026-08-20 11:38:16','2026-08-20 10:50:59'),('7a8e81f80db2d8945f027912fc79a7e1',4,'2026-09-02 21:25:48','2026-08-20 08:23:19'),('7b4df8c95189f197ec28918a81e71db5',5,'2026-08-20 11:15:51','2026-08-20 10:28:14'),('83dc09ac7f102509a99549e84a01c3d9',4,'2026-09-03 08:23:19','2026-08-20 09:26:47'),('84ecc0061acccfaabcc03d039cb2e18f',5,'2026-08-19 22:48:51','2026-08-19 21:52:17'),('8621742d24b73900d99b5d4b5546c086',5,'2026-09-03 08:24:48','2026-08-20 09:45:34'),('8a8c6deb14881368b7e2213edc26167b',5,'2026-08-20 10:45:34','2026-08-20 09:46:45'),('8af2d904654db646befbd95790ef7067',4,'2026-08-19 20:57:19','2026-08-19 19:57:33'),('93f690de543f978a2f673661f4c994a5',4,'2026-09-03 09:26:47','2026-08-20 10:27:01'),('9b0f2ca7f2c0ef6a622c00d3e6a93a78',4,'2026-09-02 20:19:32','2026-08-19 20:20:10'),('9be2a87d5fe523c1dc2c33b6f37eb537',5,'2026-08-19 22:26:54','2026-08-19 21:42:37'),('9c0fa5ed4d119bc7103c267f94827d6f',4,'2026-09-03 10:27:01','2026-08-20 12:03:46'),('9e67cf74eb908ad74bf2b47b539da7b8',5,'2026-08-20 11:01:08','2026-08-20 10:05:35'),('b57937eb5b88888e923a8ee913295ff9',4,'2026-08-20 11:34:08','2026-08-20 10:34:46'),('c24fd69ea8aeec6342ad957c3a79f0e6',5,'2026-08-20 10:54:04','2026-08-20 09:58:00'),('c49cb926cfdd44927d01923b6bb28cce',4,'2026-08-19 15:23:21','2026-08-19 14:31:32'),('c716a025070c52278cbc8260fe48d06c',4,'2026-08-20 11:07:54','2026-08-20 10:08:05'),('d65da9d7fdd4f4a9dfa0a726eb1eee49',5,'2026-08-19 21:02:04','2026-08-19 20:02:20'),('e0f707cbe3a330980d2a22bd4ee6c1fc',5,'2026-08-19 22:52:30','2026-08-19 22:00:14'),('e733ba0a9bec8f6cac6c7de8940dd337',4,'2026-08-19 21:13:55','2026-08-19 20:16:47'),('f097b395fbff9b3a9d70484bbb2e3437',5,'2026-08-20 11:05:54','2026-08-20 10:07:28'),('f1e84c0a0acff72deaf4dafb2e8b1f95',5,'2026-08-20 11:30:55','2026-08-20 10:34:02'),('f49bd13ea1bd376f1955740a2f479662',5,'2026-09-03 12:02:52','2026-08-20 13:20:29');
/*!40000 ALTER TABLE `revoked_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id_permission_id` (`role_id`,`permission_id`),
  KEY `role_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1,1,'2026-08-16 16:41:35'),(2,1,2,'2026-08-16 16:41:35'),(3,1,3,'2026-08-16 16:41:35'),(4,1,4,'2026-08-16 16:41:35'),(5,1,5,'2026-08-16 16:41:35'),(6,1,6,'2026-08-16 16:41:35'),(7,1,7,'2026-08-16 16:41:35'),(8,1,8,'2026-08-16 16:41:35'),(9,1,9,'2026-08-16 16:41:35'),(10,1,10,'2026-08-16 16:41:35'),(11,1,11,'2026-08-16 16:41:35'),(12,1,12,'2026-08-16 16:41:35'),(13,1,13,'2026-08-16 16:41:35'),(14,1,14,'2026-08-16 16:41:35'),(15,1,15,'2026-08-16 16:41:35'),(16,1,16,'2026-08-16 16:41:35'),(17,1,17,'2026-08-16 16:41:35'),(18,1,18,'2026-08-16 16:41:35'),(19,1,19,'2026-08-16 16:41:35'),(20,1,20,'2026-08-16 16:41:35'),(21,1,21,'2026-08-16 16:41:35'),(22,1,22,'2026-08-16 16:41:35'),(23,1,23,'2026-08-16 16:41:35'),(24,1,24,'2026-08-16 16:41:35'),(25,1,25,'2026-08-16 16:41:35'),(26,1,26,'2026-08-16 16:41:35'),(27,1,27,'2026-08-16 16:41:35'),(28,1,28,'2026-08-16 16:41:35'),(29,1,29,'2026-08-16 16:41:35'),(30,1,30,'2026-08-16 16:41:35'),(31,1,31,'2026-08-16 16:41:35'),(32,1,32,'2026-08-16 16:41:35'),(33,1,33,'2026-08-16 16:41:35'),(34,1,34,'2026-08-16 16:41:35'),(35,1,35,'2026-08-16 16:41:35'),(36,1,36,'2026-08-16 16:41:35'),(37,1,37,'2026-08-16 16:41:35'),(38,1,38,'2026-08-16 16:41:35'),(39,1,39,'2026-08-16 16:41:35'),(40,1,40,'2026-08-16 16:41:35'),(41,1,41,'2026-08-16 16:41:35'),(42,1,42,'2026-08-16 16:41:35'),(43,1,43,'2026-08-16 16:41:35'),(44,1,44,'2026-08-16 16:41:35'),(45,1,45,'2026-08-16 16:41:35'),(46,2,1,'2026-08-16 16:41:35'),(47,2,2,'2026-08-16 16:41:35'),(48,2,3,'2026-08-16 16:41:35'),(49,2,4,'2026-08-16 16:41:35'),(50,2,5,'2026-08-16 16:41:35'),(51,2,6,'2026-08-16 16:41:35'),(52,2,7,'2026-08-16 16:41:35'),(53,2,8,'2026-08-16 16:41:35'),(54,2,9,'2026-08-16 16:41:35'),(55,2,10,'2026-08-16 16:41:35'),(56,2,11,'2026-08-16 16:41:35'),(57,2,12,'2026-08-16 16:41:35'),(58,2,13,'2026-08-16 16:41:35'),(59,2,14,'2026-08-16 16:41:35'),(60,2,15,'2026-08-16 16:41:35'),(61,2,16,'2026-08-16 16:41:35'),(62,2,17,'2026-08-16 16:41:35'),(63,2,18,'2026-08-16 16:41:35'),(64,2,19,'2026-08-16 16:41:35'),(65,2,20,'2026-08-16 16:41:35'),(66,2,21,'2026-08-16 16:41:35'),(67,2,22,'2026-08-16 16:41:35'),(68,2,23,'2026-08-16 16:41:35'),(69,2,24,'2026-08-16 16:41:35'),(70,2,25,'2026-08-16 16:41:35'),(71,2,26,'2026-08-16 16:41:35'),(72,2,27,'2026-08-16 16:41:35'),(73,2,28,'2026-08-16 16:41:35'),(74,2,29,'2026-08-16 16:41:35'),(75,2,30,'2026-08-16 16:41:35'),(76,2,31,'2026-08-16 16:41:35'),(77,2,32,'2026-08-16 16:41:35'),(78,2,33,'2026-08-16 16:41:35'),(79,2,34,'2026-08-16 16:41:35'),(80,2,35,'2026-08-16 16:41:35'),(81,2,36,'2026-08-16 16:41:35'),(82,2,37,'2026-08-16 16:41:35'),(83,2,38,'2026-08-16 16:41:35'),(84,2,39,'2026-08-16 16:41:35'),(85,2,40,'2026-08-16 16:41:35'),(86,2,41,'2026-08-16 16:41:35'),(87,2,42,'2026-08-16 16:41:35'),(88,2,43,'2026-08-16 16:41:35'),(89,2,44,'2026-08-16 16:41:35'),(90,2,45,'2026-08-16 16:41:35'),(91,3,1,'2026-08-16 16:41:35'),(92,3,5,'2026-08-16 16:41:35'),(93,3,6,'2026-08-16 16:41:35'),(94,3,7,'2026-08-16 16:41:35'),(95,3,8,'2026-08-16 16:41:35'),(96,3,9,'2026-08-16 16:41:35'),(97,3,10,'2026-08-16 16:41:35'),(98,3,11,'2026-08-16 16:41:35'),(99,3,12,'2026-08-16 16:41:35'),(100,3,13,'2026-08-16 16:41:35'),(101,3,14,'2026-08-16 16:41:35'),(102,3,15,'2026-08-16 16:41:35'),(103,3,16,'2026-08-16 16:41:35'),(104,3,17,'2026-08-16 16:41:35'),(105,3,18,'2026-08-16 16:41:35'),(106,3,21,'2026-08-16 16:41:35'),(107,3,22,'2026-08-16 16:41:35'),(108,3,27,'2026-08-16 16:41:35'),(109,3,28,'2026-08-16 16:41:35'),(110,3,29,'2026-08-16 16:41:35'),(111,3,31,'2026-08-16 16:41:35'),(112,3,33,'2026-08-16 16:41:35'),(113,3,34,'2026-08-16 16:41:35'),(114,3,35,'2026-08-16 16:41:35'),(115,3,36,'2026-08-16 16:41:35'),(116,3,37,'2026-08-16 16:41:35'),(117,3,38,'2026-08-16 16:41:35'),(118,3,39,'2026-08-16 16:41:35'),(119,3,40,'2026-08-16 16:41:35'),(120,3,41,'2026-08-16 16:41:35'),(121,3,42,'2026-08-16 16:41:35'),(122,3,43,'2026-08-16 16:41:35'),(123,3,44,'2026-08-16 16:41:35'),(124,3,45,'2026-08-16 16:41:35'),(125,4,1,'2026-08-16 16:41:35'),(126,4,5,'2026-08-16 16:41:35'),(127,4,8,'2026-08-16 16:41:35'),(128,4,9,'2026-08-16 16:41:35'),(129,4,12,'2026-08-16 16:41:35'),(130,4,13,'2026-08-16 16:41:35'),(131,4,15,'2026-08-16 16:41:35'),(132,4,16,'2026-08-16 16:41:35'),(133,4,27,'2026-08-16 16:41:35'),(134,4,29,'2026-08-16 16:41:35'),(135,4,31,'2026-08-16 16:41:35'),(136,4,21,'2026-08-16 16:41:35'),(137,4,38,'2026-08-16 16:41:35'),(138,4,40,'2026-08-16 16:41:35'),(139,4,41,'2026-08-16 16:41:35'),(140,4,42,'2026-08-16 16:41:35'),(141,4,43,'2026-08-16 16:41:35'),(142,4,44,'2026-08-16 16:41:35'),(143,5,1,'2026-08-16 16:41:35'),(144,5,5,'2026-08-16 16:41:35'),(238,8,1,'2026-08-19 21:33:36'),(239,8,5,'2026-08-19 21:33:36'),(240,8,8,'2026-08-19 21:33:36'),(241,8,9,'2026-08-19 21:33:36'),(242,8,10,'2026-08-19 21:33:36'),(243,8,12,'2026-08-19 21:33:36'),(244,8,13,'2026-08-19 21:33:36'),(245,8,15,'2026-08-19 21:33:36'),(246,8,16,'2026-08-19 21:33:36'),(247,8,27,'2026-08-19 21:33:36'),(248,8,29,'2026-08-19 21:33:36'),(249,8,31,'2026-08-19 21:33:36'),(250,8,21,'2026-08-19 21:33:36'),(251,8,38,'2026-08-19 21:33:36'),(252,8,40,'2026-08-19 21:33:36'),(253,8,41,'2026-08-19 21:33:36'),(254,8,42,'2026-08-19 21:33:36'),(255,8,43,'2026-08-19 21:33:36'),(256,8,44,'2026-08-19 21:33:36'),(257,8,45,'2026-08-19 21:33:36'),(333,6,25,'2026-08-20 11:02:40'),(334,6,19,'2026-08-20 11:02:40'),(335,6,20,'2026-08-20 11:02:40'),(336,6,18,'2026-08-20 11:02:40');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_system` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_name` (`company_id`,`name`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `roles_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,1,'Super Admin','Full access across the entire system',1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(2,1,'Company Admin','Full access within their company',1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(3,1,'Store Manager','Manages day-to-day store operations',1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(4,1,'Cashier','Rings up sales at the register',1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(5,1,'Bagger','Assists with packing and stock visibility only',1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(6,1,'Store Admin','Full access, typically scoped to specific stores via Store Access',1,'2026-08-19 19:46:00','2026-08-19 19:46:00'),(8,1,'Cashier Supervisor','Supervises cashiers — can void sales and approve returns',1,'2026-08-19 21:33:36','2026-08-19 21:33:36');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `product_sku` varchar(60) DEFAULT NULL,
  `tax_rate_id` bigint(20) unsigned DEFAULT NULL,
  `tax_type` varchar(20) DEFAULT NULL,
  `quantity` decimal(15,4) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(7,4) NOT NULL DEFAULT 0.0000,
  `tax_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  KEY `sale_items_tax_rate_id_fk` (`tax_rate_id`),
  KEY `idx_sale_items_report_covering` (`sale_id`,`product_id`,`quantity`,`line_total`),
  CONSTRAINT `sale_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sale_items_tax_rate_id_fk` FOREIGN KEY (`tax_rate_id`) REFERENCES `tax_rates` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `company_tin` varchar(50) DEFAULT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `store_name` varchar(150) DEFAULT NULL,
  `store_address` varchar(255) DEFAULT NULL,
  `register_id` bigint(20) unsigned NOT NULL,
  `cash_session_id` bigint(20) unsigned DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `customer_name` varchar(150) DEFAULT NULL,
  `loyalty_card_id` bigint(20) unsigned DEFAULT NULL,
  `loyalty_card_number` varchar(40) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `cashier_name` varchar(150) DEFAULT NULL,
  `bagger_id` bigint(20) unsigned DEFAULT NULL,
  `bagger_name` varchar(150) DEFAULT NULL,
  `invoice_number` varchar(40) NOT NULL,
  `status` enum('completed','voided','held') NOT NULL DEFAULT 'completed',
  `sale_date` datetime NOT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `change_due` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_invoice_number` (`company_id`,`invoice_number`),
  KEY `company_id` (`company_id`),
  KEY `store_id` (`store_id`),
  KEY `register_id` (`register_id`),
  KEY `cash_session_id` (`cash_session_id`),
  KEY `customer_id` (`customer_id`),
  KEY `user_id` (`user_id`),
  KEY `sale_date` (`sale_date`),
  KEY `sales_bagger_id_fk` (`bagger_id`),
  KEY `sales_loyalty_card_id_fk` (`loyalty_card_id`),
  KEY `idx_sales_company_status_date` (`company_id`,`status`,`sale_date`),
  KEY `idx_sales_store_status_date` (`store_id`,`status`,`sale_date`),
  KEY `idx_sales_report_covering` (`company_id`,`status`,`sale_date`,`subtotal`,`discount_total`,`tax_total`,`total`),
  CONSTRAINT `sales_bagger_id_fk` FOREIGN KEY (`bagger_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sales_cash_session_id_foreign` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `sales_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `sales_loyalty_card_id_fk` FOREIGN KEY (`loyalty_card_id`) REFERENCES `loyalty_cards` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sales_register_id_foreign` FOREIGN KEY (`register_id`) REFERENCES `registers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_product_prices`
--

DROP TABLE IF EXISTS `store_product_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store_product_prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `cost_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `selling_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id_store_id` (`product_id`,`store_id`),
  KEY `store_id` (`store_id`),
  CONSTRAINT `store_product_prices_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `store_product_prices_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_product_prices`
--

LOCK TABLES `store_product_prices` WRITE;
/*!40000 ALTER TABLE `store_product_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `store_product_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `code` varchar(30) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_code` (`company_id`,`code`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `stores_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` VALUES (1,1,'Head Office','000',NULL,NULL,NULL,1,'2026-08-16 16:43:31','2026-08-20 09:21:12'),(3,1,'Store 1','101',NULL,NULL,NULL,1,'2026-08-19 19:17:39','2026-08-19 19:32:31'),(8,1,'Store 2','102',NULL,NULL,NULL,1,'2026-08-19 19:33:15','2026-08-19 19:37:01'),(15,1,'xcv','888',NULL,NULL,NULL,1,'2026-08-20 09:47:19','2026-08-20 09:47:19');
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `contact_name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `suppliers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_rates`
--

DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `rate` decimal(7,4) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_name` (`company_id`,`name`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `tax_rates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_rates`
--

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
INSERT INTO `tax_rates` VALUES (1,1,'VAT',12.0000,1,1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(2,1,'VAT EXEMPT',0.0000,0,1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(3,1,'ZERO RATED',0.0000,0,1,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(4,1,'NON VAT',0.0000,0,1,'2026-08-16 16:41:35','2026-08-16 16:41:35');
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `abbreviation` varchar(10) NOT NULL,
  `decimal_places` tinyint(3) unsigned DEFAULT 2,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `abbreviation` (`abbreviation`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'Pieces','PCS',0,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(2,'Kilogram','KG',3,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(3,'Gram','G',0,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(4,'Liter','L',3,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(5,'Milliliter','ML',0,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(6,'Meter','M',3,'2026-08-16 16:41:35','2026-08-16 16:41:35'),(7,'Box','BOX',0,'2026-08-16 16:41:35','2026-08-16 16:41:35');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_stores`
--

DROP TABLE IF EXISTS `user_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_stores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_store_id` (`user_id`,`store_id`),
  KEY `store_id` (`store_id`),
  CONSTRAINT `user_stores_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_stores`
--

LOCK TABLES `user_stores` WRITE;
/*!40000 ALTER TABLE `user_stores` DISABLE KEYS */;
INSERT INTO `user_stores` VALUES (11,5,3,0,'2026-08-19 20:09:14'),(42,4,3,0,'2026-08-20 10:44:08'),(43,4,8,0,'2026-08-20 10:44:08'),(44,4,15,0,'2026-08-20 10:44:08'),(45,4,1,0,'2026-08-20 18:44:30'),(46,21,8,1,'2026-08-20 18:59:26'),(52,58,3,1,'2026-08-20 12:16:59'),(54,64,3,1,'2026-08-20 13:24:27');
/*!40000 ALTER TABLE `user_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `failed_login_attempts` int(10) unsigned DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  KEY `company_id` (`company_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (4,1,1,'Admininstrator','admin@yahoo.com','admin1','$2y$12$Yn3pnuSCZ3SUS01Frp.DF.61J63pAUaPc0/f74eGgNrACa7kD8u46',1,NULL,'2026-08-19 21:25:48',NULL,1,'2026-08-20 10:34:08','2026-08-18 21:18:33','2026-08-20 13:20:18'),(5,1,6,'Store Admin 101','storeadmin101@yahoo.com','storeadmin101','$2y$12$AJ1oWcROTXkDkuUoWZ3zJu5RfQmX9FpWWkz6x6jVIedKU5ZDx8PB.',0,NULL,'2026-08-19 21:26:54',NULL,1,'2026-08-20 12:02:52','2026-08-19 19:53:08','2026-08-20 12:02:52'),(21,1,6,'Store Admin 102','storeadmin102@yahoo.com','storeadmin102','$2y$12$eezMOp.0w3OdwZZLcRryau1lnTV64fh1r13KTXRTrdefU0nn9YdAO',0,NULL,'2026-08-19 21:48:24',NULL,1,NULL,'2026-08-19 21:48:24','2026-08-19 21:48:24'),(49,1,NULL,'test','s@ya.co','s','$2y$12$YsAk3IYW3tAGP3TcuTmvR.X8sQP2XiapiBjMr0VHt/ZDind.vGqRK',0,NULL,'2026-08-20 11:00:58',NULL,1,NULL,'2026-08-20 11:00:57','2026-08-20 12:15:28'),(58,1,4,'Cashier1 101','cashier1_101@yahoo.com','cashier_1_101','$2y$12$/k5wp38UdtvLzYa1O6.G3ONnQ0o..9I9WWR.QnV88qfvG6Y2iU1I6',0,NULL,'2026-08-20 12:16:59',NULL,1,NULL,'2026-08-20 12:16:58','2026-08-20 13:25:10'),(64,1,4,'Cashier2 101','cashier2_101@yahoo.com','cashier_2_101','$2y$12$bLTcoluYxN.ms7M5ns7LbuMiUfPOpn9v5l1HCsz2QiT9idkM5KREa',0,NULL,'2026-08-20 13:24:27',NULL,1,NULL,'2026-08-20 13:24:27','2026-08-20 13:24:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos_system'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-22  1:01:28
